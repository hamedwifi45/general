<?php $__env->startSection('content'); ?>
<p class="h4 my-4"><?php echo e($post->title); ?></p>
<input id="postId" value="<?php echo e($post->id); ?>" type="hidden">
<div class="col-md-8">
    <div class="bg-white p-5">
        <div class="user-profile">
            <img src="<?php echo e($post->user->profile_photo_path ? : $post->user->profile_photo_url); ?>" 
                 alt="<?php echo e($post->user->name); ?>" 
                 class="profile-img">
            <div class="profile-info">
                <p class="username"><?php echo e($post->user->name); ?></p>
                <span class="post-time"><?php echo e($post->created_at->diffForHumans()); ?></span>
            </div>
        </div>

        <div class="post-content">
            <h3 class="post-title">
                <a href="<?php echo e(route('post.show' , $post->id)); ?>" class="title-link text-xl"><?php echo e($post->title); ?></a>
            </h3>
            <div class="excerpt ">
                <?php if(file_exists(public_path('storage/images/'.$post->image_path))): ?>
                    <img class='mb-4 mx-auto post-img' src="<?php echo e(asset('storage/images/' . $post->image_path)); ?>" alt="">
                <?php endif; ?>
                <p class="h6"><?php echo $post->body; ?></p>
            </div>
        </div>
        <?php if(auth()->guard()->check()): ?>
        <div class="row form-group mt-5">
            <div class="col-lg-12 col-md-6 col-xs-11">
                <form action="<?php echo e(route('comment.store')); ?>" method="post" id="comments">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <textarea name="body" rows="5" placeholder="اضف تعليقا ..." class="form-control <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id=""></textarea>
                        <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                    </div>
                    <button type="submit" class="btn btn-outline-dark mt-3" >اضف تعليق</button>
                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                </form>
            </div>
        </div>
            
        <?php else: ?>
        <div class="alert alert-info" role="alert">
            يجب عليك تسجيل الدخول لتتمكن من التعليق
        </div>
        <?php endif; ?>


        <div class="post-footer">
            <div class="meta-item">
                <i class="bi bi-table category-icon"></i>
                <span class="category-name"><?php echo e($post->category->title); ?></span>
            </div>
            <div class="meta-item comments-count">
                <i class="bi bi-chat comment-icon"></i>
                <span><?php echo e($post->comments->count()); ?></span>
            </div>
        </div>
    </div>
    <div id="comments" class="p-0 word-break container mt-5">
        <h4 class="mb-5">تعليقات</h4>
        <?php echo $__env->make('comments.all' , ['comments' => $comments], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>



<?php echo $__env->make('partiaks.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
        
        .reply-button:hover {
            color: #1a73e8 !important;
            text-decoration: underline;
        }
        
        .reply-form {
            transition: all 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.5);
        }
        
        .form-control:focus {
            border-color: #3490dc;
            box-shadow: 0 0 0 2px rgba(52, 144, 220, 0.25);
        }
    
    .post-img{
        text-align: justify;
        max-width: 600px;
        max-height: 600px ;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH T:\hsoubacadimy\general\resources\views/posts/show.blade.php ENDPATH**/ ?>