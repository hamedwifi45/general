<div class="CommentBody">
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
            <div class="card-body">
                <img src="<?php echo e($comment->user->profile_photo_path ? : $comment->user->profile_photo_url); ?>" alt="" class="rounded-full " height="50px" width="50px" style="float:right">
                <p class="mt-2 me-3" style="display: inline-block"><strong><?php echo e($comment->user->name); ?></strong></p>
                <div class="col-12">
                    <div class="row">
                        <div class="col-4">
                            <i class="bi bi-clock"></i> <span
                                class="comment_date text-secondary"><?php echo e($comment->created_at->diffForHumans()); ?></span>
                        </div>
                        <div class="col-4">
                            <span class="cursor-pointer reply-button">
                                <i class="bi bi-reply"></i><span class="comment_date text-secondary">اضافة رد</span>
                            </span>
                        </div>
                    </div>
                    <p class="mt-3"><?php echo e($comment->body); ?></p>
                    <?php if(auth()->guard()->check()): ?>
                        <form action="<?php echo e(route('replay.add')); ?>" class="replay" id="replay" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <textarea name="comment_body" rows="5" placeholder="اضف ردا"
                                    class="form-control  <?php $__errorArgs = ['comment_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                                <?php $__errorArgs = ['comment_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <input type="hidden" name="post_id" value="<?php echo e($comment->post_id); ?>">
                                <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>">
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-outline-dark my-2" value="تعليق">
                            </div>


                        </form>
                    <?php else: ?>
                        <div class="alert alert-info replay" role="alert">
                            الرجاء تسجيل الدخول
                        </div>
                    <?php endif; ?>
                    
                    <?php echo $__env->make('comments.all', ['comments' => $comment->replies], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $(".replay").hide();
            $(".reply-button").click(function(event){
                ele = $(this).parents("div.row").nextAll().slice(1,2).slideToggle('slow');
            });
        });
    </script>
<?php $__env->stopSection(); ?><?php /**PATH T:\hsoubacadimy\general\resources\views/comments/all.blade.php ENDPATH**/ ?>