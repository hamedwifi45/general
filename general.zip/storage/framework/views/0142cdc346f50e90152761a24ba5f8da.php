<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('success')); ?>

</div>
    
<?php endif; ?><?php /**PATH T:\hsoubacadimy\general\resources\views/alerts/success.blade.php ENDPATH**/ ?>