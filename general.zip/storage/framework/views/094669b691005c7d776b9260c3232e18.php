<div class="col-md-4">
    <div class="card">
        <h5 class="card-header">
            التصنيفات
        </h5>
        <div class="card-body">
            <ul class="nav flex-column p-0 " style="list-style: none !important">
                <li class="nav-item">
                    <a href="<?php echo e(url('/')); ?>" class="nav-link text-dark">
                    جميع التصنيفات (<?php echo e($post_number); ?>)
                    </a>
                </li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('category' , [$cat->id ,$cat->slug])); ?>" class=" text-dark nav-link">
                        <?php echo e($cat->title); ?> (<?php echo e($cat->posts()->count()); ?>)
                    </a>
                </li>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    
    <div class="card my-4 text-right">
        <h4 class="card-header">
            اخر تعليقات
        </h4>
        <ul class="list-group p-0">
            <?php $__currentLoopData = $recent_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item">
                <a href="<?php echo e(route('post.show', $comment->Post->slug)); ?>#comments">
                    <img style="float:right" src="<?php echo e($comment->user->profile_photo_path ? : $comment->user->profile_photo_url); ?>" width="40px" class="rounded-full"/>
                    <span class="mt-1 me-1 d-inline-block"><strong><?php echo e($comment->user->name); ?></strong></span> 
                    <span><?php echo e(\Illuminate\Support\Str::limit($comment->body, 60)); ?></span>
                </a>
            </li>            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div><?php /**PATH T:\hsoubacadimy\general\resources\views/partiaks/sidebar.blade.php ENDPATH**/ ?>