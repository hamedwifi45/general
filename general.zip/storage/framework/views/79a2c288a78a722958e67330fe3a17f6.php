<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <p class='h4 my-4'>
        <?php echo e($title); ?>

    </p>
</div>
<div class="col-md-8">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-3 animated-card">
        <div class="card-body position-relative">
            <div class="user-profile">
                <img src="<?php echo e($post->user->profile_photo_path ? : $post->user->profile_photo_url); ?>" 
                     alt="<?php echo e($post->user->name); ?>" 
                     class="profile-img">
                <div class="profile-info">
                    <p class="username"><?php echo e($post->user->name); ?></p>
                    <span class="post-time"><?php echo e($post->created_at->diffForHumans()); ?></span>
                </div>
            </div>
    
            <div class="post-content">
                <h3 class="post-title">
                    <a href="<?php echo e(route('post.show' , $post->slug)); ?>" class="title-link text-xl"><?php echo e($post->title); ?></a>
                </h3>
                <div class="excerpt">
                    <?php echo Str::limit($post->body, 200, '...'); ?>

                </div>
            </div>
    
            <div class="post-footer">
                <div class="meta-item">
                    <i class="bi bi-table category-icon"></i>
                    <span class="category-name"><?php echo e($post->category->title); ?></span>
                </div>
                <div class="meta-item comments-count">
                    <i class="bi bi-chat comment-icon"></i>
                    <span><?php echo e($post->comments->count()); ?></span>
                </div>
            </div>
    
            <div class="card-overlay"></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
        
            <ul
                class="pagination  justify-content-center  "
            >
            <?php echo e($posts->links()); ?>

            </ul>
        
        
</div>

<?php echo $__env->make('partiaks.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH T:\hsoubacadimy\general\resources\views/index.blade.php ENDPATH**/ ?>