<?php

declare(strict_types=1);

return [
    'next'     => 'التالي &raquo;',
    'previous' => '&laquo; السابق',
];
